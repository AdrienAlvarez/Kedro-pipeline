"""
This is a boilerplate pipeline 'model_training'
generated using Kedro 0.19.5
"""
from kedro.pipeline import Pipeline, node, pipeline
from .nodes import load_data, train_model, save_model

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([
        node(
            func=load_data,
            inputs=["train_data", "test_data"],
            outputs=["X_train", "y_train", "X_test", "y_test"],
            name="load_data_node"
        ),
        node(
            func=train_model,
            inputs=["X_train", "y_train"],
            outputs="model",
            name="train_model_node"
        ),
        node(
            func=save_model,
            inputs=["model", "model_filepath"],
            outputs=None,
            name="save_model_node"
        ),
    ])