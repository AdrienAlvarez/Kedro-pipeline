import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv1D, MaxPooling1D, Flatten
import tensorflow as tf

# Création du modèle de réseau de neurones
def create_model(input_shape):
    model = Sequential()
    
    # Couche de convolution 1. (Détecte des motifs dans les images)
    model.add(Conv1D(32, kernel_size=2, activation='relu', input_shape=input_shape))
    # Couche de max pooling (Réduit la taille des images, garde les informations importantes)
    model.add(MaxPooling1D(pool_size=2))
    
    # Deuxième couche de convolution
    model.add(Conv1D(64, kernel_size=2, activation='relu'))
    # Deuxième couche de max pooling
    model.add(MaxPooling1D(pool_size=2))
    
    # Couche d'aplatissement (Transforme les matrices 2D en vecteur 1D pour s'adapter aux couches denses)
    model.add(Flatten())
    
    # Couche dense (Neurones entièrement connectés, effectue la classification ou la régression)
    model.add(Dense(128, activation='relu'))
    
    # Couche de sortie 
    model.add(Dense(7, activation='linear'))
    
    # Compilation du modèle (Prépare le modèle pour l'entraînement en définissant la fonction de perte, l'optimiseur et les métriques)
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

# Entraînement du modèle (b = Nombre d'exemples traités avant une mise à jour du modèle, v = Fraction des données utilisée pour valider le modèle pendant l'entraînement)
def train_model(X_train, y_train):
    X_train_reshaped = X_train.values.reshape((X_train.shape[0], X_train.shape[1], 1))
    model = create_model((X_train.shape[1], 1))
    model.fit(X_train_reshaped, y_train.values, epochs=10, batch_size=32, validation_split=0.2)
    return model

# Évaluation du modèle
def evaluate_model(model, X_test, y_test):
    X_test_reshaped = X_test.values.reshape((X_test.shape[0], X_test.shape[1], 1))
    results = model.evaluate(X_test_reshaped, y_test.values)
    
    # Résultats de l'évaluation
    evaluation_results = pd.DataFrame({
        "metric": ["MSE", "MAE"],
        "value": [results[0], results[1]]
    })
    return evaluation_results