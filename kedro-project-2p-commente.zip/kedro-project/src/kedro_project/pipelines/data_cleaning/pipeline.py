from kedro.pipeline import Pipeline, node
from .nodes import clean_data, split_data

def create_pipeline(**kwargs) -> Pipeline:
    return Pipeline(
        [
            node(
                func=clean_data,
                inputs="raw_data",
                outputs="cleaned_data",
                name="clean_data_node"
            ),
            node(
                func=split_data,
                inputs="cleaned_data",
                outputs=["X_train", "X_test", "y_train", "y_test"],
                name="split_data_node"
            )
        ]
    )
