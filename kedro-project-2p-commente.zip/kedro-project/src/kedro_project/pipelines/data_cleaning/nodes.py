import pandas as pd
from sklearn.model_selection import train_test_split

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df_cleaned = df.apply(pd.to_numeric, errors='coerce')
    df_cleaned = df_cleaned.dropna()
    return df_cleaned

def split_data(df: pd.DataFrame) -> tuple:
    target_columns = [
        "after_exam_125_Hz", "after_exam_250_Hz", "after_exam_500_Hz",
        "after_exam_1000_Hz", "after_exam_2000_Hz", "after_exam_4000_Hz", "after_exam_8000_Hz"
    ]
    X = df.drop(target_columns, axis=1)
    y = df[target_columns]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test
