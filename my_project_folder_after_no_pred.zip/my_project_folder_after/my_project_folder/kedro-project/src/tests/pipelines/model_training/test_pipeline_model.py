import pytest
import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
import mlflow
from kedro_project.pipelines.model_training.nodes import create_model, train_model, evaluate_model

# Désactiver les avertissements spécifiques
@pytest.mark.filterwarnings("ignore:.*:DeprecationWarning")

# Fixture pour fournir des données d'exemple pour l'entraînement et les tests
@pytest.fixture
def sample_data():
    X_train = pd.DataFrame(np.random.rand(100, 10))
    y_train = pd.DataFrame(np.random.rand(100, 7))
    X_test = pd.DataFrame(np.random.rand(20, 10))
    y_test = pd.DataFrame(np.random.rand(20, 7))
    return X_train, y_train, X_test, y_test

# Test de la création du modèle
def test_create_model():
    input_shape = (10, 1)
    model = create_model(input_shape)
    assert isinstance(model, Sequential), "Le modèle doit être une instance de Sequential"
    assert len(model.layers) == 7, "Le modèle doit avoir 7 couches"
    assert model.input_shape == (None, 10, 1), "La forme de l'entrée doit être correcte"

# Test de l'entraînement du modèle
def test_train_model(sample_data):
    X_train, y_train, _, _ = sample_data
    model = train_model(X_train, y_train)
    assert isinstance(model, Sequential), "Le modèle doit être une instance de Sequential après l'entraînement"
    mlflow.end_run()  # Assurez-vous de terminer la session MLflow

# Test de l'évaluation du modèle
def test_evaluate_model(sample_data):
    X_train, y_train, X_test, y_test = sample_data
    model = train_model(X_train, y_train)
    evaluation_results = evaluate_model(model, X_test, y_test)
    assert isinstance(evaluation_results, pd.DataFrame), "Les résultats de l'évaluation doivent être un DataFrame"
    assert list(evaluation_results.columns) == ["metric", "value"], "Les colonnes du DataFrame doivent être 'metric' et 'value'"
    assert evaluation_results.shape[0] == 2, "Le DataFrame doit avoir 2 lignes, une pour chaque métrique"
    mlflow.end_run()  # Assurez-vous de terminer la session MLflow
