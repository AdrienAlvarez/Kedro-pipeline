import pytest
import pandas as pd
import numpy as np
import sys
from dotenv import load_dotenv
import os

# Charger les variables d'environnement depuis le fichier .env
dotenv_path = os.path.join(os.path.dirname(__file__), '../../../..', '.env')
load_dotenv(dotenv_path)

# Ajouter le répertoire src au sys.path
src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..', 'src'))
if src_path not in sys.path:
    sys.path.append(src_path)

from kedro_project.pipelines.data_cleaning.nodes import clean_data

# Fixture pour fournir le dataframe d'exemple
@pytest.fixture
def dataframe_exemple():
    # Chemin vers le fichier CSV
    csv_path = os.path.join(os.path.dirname(__file__), '../../../..', 'data', '01_raw', 'tonal_exams.csv')
    # Lire le fichier CSV dans un DataFrame
    df = pd.read_csv(csv_path)
    return df

# Test pour vérifier que les valeurs NaN sont supprimées
def test_suppression_nan(dataframe_exemple):
    df_nettoye = clean_data(dataframe_exemple)
    assert df_nettoye.isna().sum().sum() == 0, "Il ne doit y avoir aucune valeur NaN après le nettoyage"

# Test pour vérifier que les noms de colonnes restent les mêmes
def test_noms_colonnes(dataframe_exemple):
    df_nettoye = clean_data(dataframe_exemple)
    assert list(df_nettoye.columns) == list(dataframe_exemple.columns), "Les noms de colonnes doivent rester les mêmes après le nettoyage"

# Test pour vérifier que le dataframe n'est pas vide après le nettoyage
def test_dataframe_non_vide(dataframe_exemple):
    df_nettoye = clean_data(dataframe_exemple)
    assert not df_nettoye.empty, "Le dataframe ne doit pas être vide après le nettoyage"

# Test pour vérifier que les types de données sont numériques après le nettoyage
def test_types_donnees(dataframe_exemple):
    df_nettoye = clean_data(dataframe_exemple)
    assert all(df_nettoye.dtypes == 'float64'), "Toutes les colonnes doivent être de type float64 après le nettoyage"

# Test pour vérifier que les lignes avec des NaN sont supprimées
def test_suppression_lignes_nan():
    df = pd.DataFrame({
        'col1': [1, 2, np.nan, 4],
        'col2': [np.nan, 2, 3, 4]
    })
    df_nettoye = clean_data(df)
    assert df_nettoye.shape[0] == 2, "Les lignes contenant des NaN doivent être supprimées"

# Test pour vérifier que la fonction peut gérer un dataframe vide
def test_dataframe_vide():
    df = pd.DataFrame(columns=['col1', 'col2'])
    df_nettoye = clean_data(df)
    assert df_nettoye.empty, "Le nettoyage d'un dataframe vide doit retourner un dataframe vide"

# Test pour vérifier que la fonction peut gérer un dataframe sans NaN
def test_sans_nan():
    df = pd.DataFrame({
        'col1': [1, 2, 3, 4],
        'col2': [5, 6, 7, 8]
    })
    df_nettoye = clean_data(df)
    assert df_nettoye.equals(df), "Un dataframe sans NaN doit rester inchangé"

# Test pour vérifier que les données non numériques sont gérées correctement
def test_donnees_non_numeriques():
    df = pd.DataFrame({
        'col1': [1, 2, 'trois', 4],
        'col2': [5, 6, 7, 'huit']
    })
    df_nettoye = clean_data(df)
    assert df_nettoye.isna().sum().sum() == 0, "Les données non numériques doivent être converties en NaN et ensuite supprimées"
    assert df_nettoye.shape[0] == 2, "Les lignes contenant des données non numériques doivent être supprimées"

# Test pour vérifier que les colonnes sont préservées après le nettoyage
def test_preservation_colonnes(dataframe_exemple):
    df_nettoye = clean_data(dataframe_exemple)
    assert all(col in df_nettoye.columns for col in dataframe_exemple.columns), "Toutes les colonnes originales doivent être préservées après le nettoyage"
