from .pipelines import data_cleaning, model_training, model_prediction

def register_pipelines():
    data_cleaning_pipeline = data_cleaning.create_pipeline()
    model_training_pipeline = model_training.create_pipeline()
    model_prediction_pipeline = model_prediction.create_pipeline()

    return {
        "__default__": data_cleaning_pipeline + model_training_pipeline + model_prediction_pipeline,
        "data_cleaning": data_cleaning_pipeline,
        "model_training": model_training_pipeline,
        "model_prediction": model_prediction_pipeline,
    }
