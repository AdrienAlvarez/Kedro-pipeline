import pandas as pd
from tensorflow.keras.models import load_model
import tensorflow as tf
import os

MODEL_PATH = 'data/05_modelsave/model.h5'

def load_trained_model():
    if os.path.exists(MODEL_PATH):
        model = load_model(MODEL_PATH, custom_objects={'mse': tf.keras.losses.MeanSquaredError()})
        return model
    else:
        raise FileNotFoundError("Model file not found. Train the model first.")

def predict(model, X_input):
    # Reshape X_input to be 3D
    X_input_reshaped = X_input.values.reshape((X_input.shape[0], X_input.shape[1], 1))
    predictions = model.predict(X_input_reshaped)
    return pd.DataFrame(predictions, columns=['after_exam_125hz', 'after_exam_250hz', 'after_exam_500hz',
                                              'after_exam_1000hz', 'after_exam_2000hz', 'after_exam_4000hz',
                                              'after_exam_8000hz'])
