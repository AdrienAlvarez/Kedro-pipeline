# model_prediction/__init__.py

from .pipeline import create_pipeline
