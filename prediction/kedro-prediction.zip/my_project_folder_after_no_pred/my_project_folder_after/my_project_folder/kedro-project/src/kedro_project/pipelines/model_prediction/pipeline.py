from kedro.pipeline import Pipeline, node
from .nodes import load_trained_model, predict

def create_pipeline(**kwargs):
    return Pipeline(
        [
            node(
                func=load_trained_model,
                inputs=None,
                outputs="trained_model",
                name="load_model_node",
            ),
            node(
                func=predict,
                inputs=["trained_model", "input_data"],
                outputs="predictions",
                name="predict_node",
            ),
        ]
    )
