from flask import Flask, request, jsonify
import pandas as pd
from kedro.framework.startup import bootstrap_project
from kedro.framework.session import KedroSession
from kedro.config import ConfigLoader
from pathlib import Path
import os

app = Flask(__name__)
bootstrap_project(Path.cwd())

# Import functions from nodes.py
from kedro_project.pipelines.model_training.nodes import train_model, load_trained_model, predict

# Define Flask route for POST requests
@app.route("/predict", methods=["POST"])
def predict_endpoint():
    data = request.json
    input_data = pd.DataFrame(data)
    
    try:
        model = load_trained_model()
    except FileNotFoundError:
        return jsonify({"error": "Model not found. Please train the model first."}), 400
    
    predictions = predict(model, input_data)
    return predictions.to_json(orient='records')

@app.route("/train", methods=["POST"])
def train_endpoint():
    data = request.json
    input_data = pd.DataFrame(data)
    
    X_train = input_data[['before_exam_125hz', 'before_exam_250hz', 'before_exam_500hz', 
                          'before_exam_1000hz', 'before_exam_2000hz', 'before_exam_4000hz', 
                          'before_exam_8000hz']]
    y_train = input_data[['after_exam_125hz', 'after_exam_250hz', 'after_exam_500hz', 
                          'after_exam_1000hz', 'after_exam_2000hz', 'after_exam_4000hz', 
                          'after_exam_8000hz']]
    
    train_model(X_train, y_train)
    return jsonify({"message": "Model trained successfully!"})

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
