"""
This is a boilerplate pipeline 'model_training'
generated using Kedro 0.19.5
"""
import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle

def load_data(train_data: pd.DataFrame, test_data: pd.DataFrame):
    X_train = train_data.drop(columns=["target"])  # Remplacez "target" par le nom de votre colonne cible
    y_train = train_data["target"]
    X_test = test_data.drop(columns=["target"])
    y_test = test_data["target"]
    return X_train, y_train, X_test, y_test

def train_model(X_train: pd.DataFrame, y_train: pd.Series) -> LinearRegression:
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model

def save_model(model: LinearRegression, filepath: str):
    with open(filepath, "wb") as f:
        pickle.dump(model, f)
