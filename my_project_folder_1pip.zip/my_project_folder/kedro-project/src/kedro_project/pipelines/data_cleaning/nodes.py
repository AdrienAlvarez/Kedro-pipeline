"""
This is a boilerplate pipeline 'data_cleaning'
generated using Kedro 0.19.5
"""
import pandas as pd
from sklearn.model_selection import train_test_split

def preprocess_data(input_datas: pd.DataFrame) -> pd.DataFrame:
    # Convertir les colonnes en type numérique
    input_datas = input_datas.apply(pd.to_numeric, errors='coerce')
    
    # Remplacer les valeurs négatives par zéro
    input_datas[input_datas < 0] = 0
    
    # Remplir les valeurs manquantes avec la moyenne de la colonne
    input_datas = input_datas.fillna(input_datas.mean())
    
    # Classement des colonnes par ordre alphabétique
    shaped_datas = input_datas.sort_index(axis=1)
    
    return shaped_datas

def split_data(data: pd.DataFrame, test_size: float = 0.2, random_state: int = 42):
    train_data, test_data = train_test_split(data, test_size=test_size, random_state=random_state)
    return train_data, test_data