from kedro.pipeline import Pipeline, node
from .nodes import preprocess_data, split_data

def create_pipeline(**kwargs):
    return Pipeline(
        [
            node(
                func=preprocess_data,
                inputs="raw_data",
                outputs="cleaned_data",
                name="preprocess_data_node",
            ),
            node(
                func=split_data,
                inputs="cleaned_data",
                outputs=["train_data", "test_data"],
                name="split_data_node",
            ),
        ]
    )