import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv1D, MaxPooling1D, Flatten, Dropout
import tensorflow as tf

def create_model(input_shape):
    model = Sequential()
    model.add(Conv1D(32, kernel_size=2, activation='relu', input_shape=input_shape))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Conv1D(64, kernel_size=2, activation='relu'))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dense(7, activation='linear'))  # Assuming 7 target variables
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def train_model(X_train, y_train):
    # Reshape X_train to be 3D
    X_train_reshaped = X_train.values.reshape((X_train.shape[0], X_train.shape[1], 1))
    model = create_model((X_train.shape[1], 1))
    model.fit(X_train_reshaped, y_train.values, epochs=10, batch_size=32, validation_split=0.2)
    return model

def evaluate_model(model, X_test, y_test):
    # Reshape X_test to be 3D
    X_test_reshaped = X_test.values.reshape((X_test.shape[0], X_test.shape[1], 1))
    results = model.evaluate(X_test_reshaped, y_test.values)
    # Extract loss (MSE) and MAE from the results
    evaluation_results = pd.DataFrame({
        "metric": ["MSE", "MAE"],
        "value": [results[0], results[1]]
    })
    return evaluation_results
